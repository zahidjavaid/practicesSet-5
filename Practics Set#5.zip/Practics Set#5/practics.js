
function addNumbers(numb1, numb2) {
	let sum = numb1 + numb2;
	return sum;
}

console.log(addNumbers()2, 3)