for (let clap=0; clap < 50; clap++){
	console.log("Clap!");
}
for (let numb = 1; numb <= 1000; numb++){
	console.log(numb);
}