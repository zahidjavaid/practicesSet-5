function clickJump(){
	let numb1 =  parseInt(document.querySelector("#inp1").value);
	let numb2 =  parseInt(document.querySelector("#inp2").value);
	let numb3 =  parseInt(document.querySelector("#jump").value);

	for (let numb4 = 4; numb4 <=33; numb4+=3){
		console.log(numb4);
	}

	for (let numb4 = 4; numb4 <=33; numb4+=5){
		console.log(numb4);
	}
}
