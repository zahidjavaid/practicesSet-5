function clickPrint(){
	let numb1 = parseInt(document.querySelector("#inp1").value);
	let numb2 = parseInt(document.querySelector("#inp2").value);
	// return numb1, numb2;

	for (let numb3 = 4; numb3 <= 133; numb3++){
		console.log(numb3);

	}
}


// for (let numb3 = 4; numb3 <= 133; numb3++){
// 		console.log("START number is 4 & STOP number 133 " + numb3);
// }