let sentence = "";
for(let numb =1; numb <=1000; numb++){
	sentence = sentence + "" + numb + ", ";	
}
console.log(sentence);