for (let numb = 1000; numb <= 1; numb--){
	console.log(numb);
}