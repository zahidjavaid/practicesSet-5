for (let numb = 1; numb <= 1000; numb++){
	console.log(numb);
}