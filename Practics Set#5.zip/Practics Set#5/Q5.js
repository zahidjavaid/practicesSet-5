for (let numb = 1; numb <= 100; numb++){
	console.log (numb * numb * numb);
}