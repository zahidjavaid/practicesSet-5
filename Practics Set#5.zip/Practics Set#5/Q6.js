for (let numb = 1; numb <= 100; numb++){
	if(numb%2 === 0)
	{
		console.log(numb)
	}
}

// for (let numb = 1; numb <= 100; numb++){
// 	if(numb%2 === 1)
// 	{
// 		console.log(numb)
// 	}
// }