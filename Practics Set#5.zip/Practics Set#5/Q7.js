for (let numb = 7; numb <= 82; numb++)
	if (numb%5 === 0)
	{
		console.log(numb);

}