let sentence = "";
for (let even = 1; even <=99; even++){

if(even%2 === 0) {
	sentence = sentence + "" + even + ", ";
	{
		console.log(sentence);
	}
}
}


// for(let numb = 1; numb <=100; numb++) {
// 	console.log(numb);
// }
