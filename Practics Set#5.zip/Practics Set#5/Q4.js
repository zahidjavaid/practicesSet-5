for (let square = 1; square <= 100; square++){
	console.log(square*square);
}