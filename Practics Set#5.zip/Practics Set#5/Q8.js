for (let numb = 7; numb <=82; numb++)
	if (numb%2 === 0)
	{
		console.log(numb);
	}